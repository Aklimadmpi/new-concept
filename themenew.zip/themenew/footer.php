<!-- footer part start -->
<footer class="container">
    <div class="row">
        <div class="col-sm-4 footer_left">1</div>
        <div class="col-sm-4 footer_middle">2</div>
        <div class="col-sm-4 footer_right">3</div>
    </div>
</footer>
<!-- footer part end -->

<?php wp_footer();?>
</body>
</html>